//
//  Favorite.swift
//  favorites
//
//  Created by Aileen Pierce
//  Copyright (c) Aileen Pierce. All rights reserved.
//

import Foundation

class Favorite {
    var favBook : String?
    var favAuthor : String?
}
