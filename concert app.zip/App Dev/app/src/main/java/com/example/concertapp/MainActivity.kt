package com.example.concertapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    //@SuppressLint("WrongViewCast")
    fun submit(view: View) {
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        val headLineID = radioGroup.checkedRadioButtonId
        var headLiner : CharSequence = " "

        val checkBox1 = findViewById<CheckBox>(R.id.checkBox1)
        val checkBox2 = findViewById<CheckBox>(R.id.checkBox2)
        val checkBox3 = findViewById<CheckBox>(R.id.checkBox3)
        val checkBox4 = findViewById<CheckBox>(R.id.checkBox4)
        val checkBox5 = findViewById<CheckBox>(R.id.checkBox5)
        val checkBox6 = findViewById<CheckBox>(R.id.checkBox6)
        var lineUp = " "

        val spinner = findViewById<Spinner>(R.id.spinner)

        val switch = findViewById<SwitchMaterial>(R.id.nightShow)

        if (switch.isChecked){
            headLiner = switch.text.toString() + " $headLiner"
        }

        if (checkBox1.isChecked){
            lineUp += " " + checkBox1.text
        }
        if (checkBox2.isChecked){
            lineUp += " " + checkBox2.text
        }
        if (checkBox3.isChecked){
            lineUp += " " + checkBox3.text
        }
        if (checkBox4.isChecked){
            lineUp += " " + checkBox4.text
        }
        if (checkBox5.isChecked){
            lineUp += " " + checkBox5.text
        }
        if (checkBox6.isChecked){
            lineUp += " " + checkBox6.text
        }
        if (lineUp.isNotEmpty()){
            lineUp = lineUp
        }

        val location = "at " + spinner.selectedItem

        val layoutRoot = findViewById<ConstraintLayout>(R.id.root_layout)
        if (headLineID == -1){
            val headLinerSnackbar = Snackbar.make(layoutRoot, "Please select a headliner" , Snackbar.LENGTH_SHORT)
            headLinerSnackbar.show()
        }
        else {
            headLiner = findViewById<RadioButton>(headLineID).text
        }

        val textMessage = findViewById<TextView>(R.id.textMessage)

        textMessage.text = "You want to see $headLiner in concert with $lineUp"

    }
}

